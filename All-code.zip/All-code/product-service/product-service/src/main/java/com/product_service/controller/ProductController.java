package com.product_service.controller;

import com.product_service.model.Product;
import com.product_service.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    ProductService productService;

    @GetMapping(name = "/{productId}")
    public ResponseEntity<?> fetchProduct(@PathVariable Long productId) {
        Optional<Product> product = productService.fetchProductById(productId);

        if (product.isPresent()) {
            return new ResponseEntity(product.get(), HttpStatus.OK);
        }

        ResponseEntity<String> resourceNotFound = new ResponseEntity<>("Resource Not Found", HttpStatus.NOT_FOUND);
        return resourceNotFound;

    }

    @PostMapping
    public ResponseEntity<?> createProduct(@RequestBody Product productRequest) {

        Product productResponse = productService.createProduct(productRequest);

        return new ResponseEntity(productResponse, HttpStatus.CREATED);
    }
}
