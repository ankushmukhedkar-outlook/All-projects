package com.product_service.model;

import jakarta.persistence.*;

@Entity
public class Product
{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long produt_id;

    @Column(name = "product_name")
    private String poduct_name;

    @Column(name = "product_description")
    private String product_description;

    @Column(name = "product_price")
    private double price;

    @Column(name = "product_imageUrl")
    private String product_imageUrl;

    public Product() {
    }

    public Product(Long produt_id, String poduct_name, String product_description, double price, String product_imageUrl) {
        this.produt_id = produt_id;
        this.poduct_name = poduct_name;
        this.product_description = product_description;
        this.price = price;
        this.product_imageUrl = product_imageUrl;
    }

    public Long getProdut_id() {
        return produt_id;
    }

    public void setProdut_id(Long produt_id) {
        this.produt_id = produt_id;
    }

    public String getPoduct_name() {
        return poduct_name;
    }

    public void setPoduct_name(String poduct_name) {
        this.poduct_name = poduct_name;
    }

    public String getProduct_description() {
        return product_description;
    }

    public void setProduct_description(String product_description) {
        this.product_description = product_description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProduct_imageUrl() {
        return product_imageUrl;
    }

    public void setProduct_imageUrl(String product_imageUrl) {
        this.product_imageUrl = product_imageUrl;
    }
}
